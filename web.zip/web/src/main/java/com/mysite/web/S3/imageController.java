package com.mysite.web.S3;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class imageController {
	
	private final imageService imageService;
	
	@PostMapping("/s3/upload")
	public ResponseEntity<?> s3Upload(@RequestPart(value = "image", required = false) MultipartFile image){
	  String profileImage = imageService.upload(image);
	  return ResponseEntity.ok(profileImage);
	}

}
