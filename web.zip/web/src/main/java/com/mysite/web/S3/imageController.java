package com.mysite.web.S3;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.mysite.web.post.PostForm;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class imageController {
	
	private final imageService imageService;
	
	
	@GetMapping("/s3/upload")
	public String go_s3(ContentForm form)
	{
		return "s3Upload";
	}
	@PostMapping("/s3/upload")
	public String s3Upload(ContentForm form,BindingResult bindingResult){
		MultipartFile file = form.getFile();
	  try {
		String profileImage =imageService.saveFile(file);
	} catch (IOException e) {
		e.printStackTrace();
		
	}
	  return "redirect:/";
	}

}
