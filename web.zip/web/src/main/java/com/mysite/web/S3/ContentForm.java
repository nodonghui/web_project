package com.mysite.web.S3;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class ContentForm {
	
	MultipartFile file; 

}
